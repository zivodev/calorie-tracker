package com.getcapacitor.myapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
